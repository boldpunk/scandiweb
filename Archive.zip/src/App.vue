<template>
<div>
    <router-link to="/"></router-link>
  <router-view/>
</div>
</template>

<script>

</script>

<style>

</style>
